<?php 

$host = "localhost";
$dbname = "lupita_buku";
$username = "root";
$password = " ";
$db = "";
?>
